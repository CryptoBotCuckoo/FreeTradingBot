from btbot import *

bot = StartBot()
bot.run()